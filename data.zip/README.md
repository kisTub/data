# data
a sever data repository

# 如何使用本data来对服务器存档进行测试？
这里以脱机的单人模式为例，有两种可行的方法。
## 新建世界
在你的 save 中创建一个任意名称的文件夹，注意，请勿使用非英文以及中划线和下划线的其他字符。创建好后，克隆本仓库到此文件夹。克隆完成后，此时此文件夹中应该只有 data 文件夹而不应有其他文件。如果有，请临时复制到其他地方或删除。打开你的Minecraft启动器，进入游戏，创建一个新的世界，且新世界名应该和之前创建的文件夹名一致。进入新世界成功后，游戏内会显示一些原版没有的提示信息，说明 data 载入成功。
## 对旧存档进行更改
先将旧存档中的所有文件复制到一个临时文件夹中，注意，此时若直接保留旧的 data 文件，则可能会导致新的数据被救数据覆盖。所以建议删除旧的 data 中的 functions 和 advancemnts 文件夹以确保新的 data 数据能稳定载入——你可以在执行本工作前做好相应文件的备份。现在，你的存档文件夹应该空空如也。于是我们克隆本 data 仓库到此存档文件夹。完成克隆后，将之前的临时文件全部剪切到原位置，新的具有本 data 数据的存档便诞生了。你可以在旧存档中进行测试，以确保其兼容性。

# 配置
有关全局配置：
* _ADM:config
* _ADM:setting/*
    * actionbar 玩家活动栏显示
    * afk_pool_position 挂机池位置
    * app_area_filter 主城范围过滤器
    * app_area_main 定义主城主范围
    * app_area_non_op_player 主城范围无管理权限玩家
    * app_back 主城返回
    * app_mob 主城生物
    * app_player_effect 主城玩家药水效果
    * app_position 主城范围
    * ctrl_around_nether 地狱门邻近地区管制
    * ctrl_entity 管制实体
    * ctrl_item 管制物品
    * ctrl_y255_block 管制y=255方块
    * enther_nether_text 地狱的进入文本
    * gamemode_survival 模式改为生存
    * login_close 登录系统关闭
    * login_debug 登录系统调试
    * login_relogin 再次登录
    * login_std 标准登录模式
    * menu_display 菜单显示
    * prefix_display 称号显示
    * prefix_join 加入称号
    * random_tp 随机tp
    * set_spawnpoint 设置重生点
    * sign_reward 签到奖励
    * suicide 自刎
使用标签开关功能：
* 控制自动虚脱效果 no_auto_weakness



